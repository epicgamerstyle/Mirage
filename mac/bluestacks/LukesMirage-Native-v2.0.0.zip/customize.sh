#!/system/bin/sh
# ============================================================================
# customize.sh — Luke's Mirage Native Layer: Install-time validation
# ============================================================================
# Runs during Magisk module installation (before the module is activated).
# Validates prerequisites, checks for the companion LSPosed module, verifies
# Zygisk availability, and ensures the profile system is present.
#
# Exit 0 = install proceeds.  Exit 1 = install aborted with error message.
# ============================================================================

# ── Magisk installer provides these variables ──
# MODPATH  = where the module will be installed (/data/adb/modules/<id>)
# TMPDIR   = temp extraction directory
# ZIPFILE  = the module zip being installed

SKIPUNZIP=0

# ── Helpers ──
ui_print() { echo "$1"; }
abort() { ui_print ""; ui_print "ERROR: $1"; ui_print ""; exit 1; }
check() { ui_print "  [+] $1"; }
warn()  { ui_print "  [!] $1"; }

ui_print ""
ui_print "============================================"
ui_print "  Luke's Mirage — Native Layer v2.0.0"
ui_print "  ReZygisk module for deep device spoofing"
ui_print "============================================"
ui_print ""

# ── 1. Verify Magisk version ──
if [ "$MAGISK_VER_CODE" -lt 20400 ] 2>/dev/null; then
    abort "Magisk v20.4+ required (found: $MAGISK_VER_CODE)"
fi
check "Magisk version: $MAGISK_VER ($MAGISK_VER_CODE)"

# ── 2. Verify Zygisk API provider is available ──
# ReZygisk provides the Zygisk API on Kitsune Magisk. ZygiskSU/ZygiskNext also work.
ZYGISK_OK=0
if [ -d "/data/adb/modules/rezygisk" ] && [ ! -f "/data/adb/modules/rezygisk/disable" ]; then
    check "Zygisk provider: ReZygisk"
    ZYGISK_OK=1
elif [ -d "/data/adb/modules/zygisksu" ] && [ ! -f "/data/adb/modules/zygisksu/disable" ]; then
    check "Zygisk provider: ZygiskSU"
    ZYGISK_OK=1
elif [ -f "/data/adb/magisk/zygisk_enabled" ]; then
    check "Zygisk provider: Magisk native"
    ZYGISK_OK=1
fi

if [ "$ZYGISK_OK" != "1" ]; then
    warn "No Zygisk API provider detected — module requires ReZygisk to function"
    warn "Install ReZygisk from the Magisk module repository"
    # Don't abort — user might be installing prerequisites out of order
fi

# ── 3. Check for companion LSPosed module ──
LSPOSED_OK=0
if [ -d "/data/adb/modules/zygisk_lsposed" ] && [ ! -f "/data/adb/modules/zygisk_lsposed/disable" ]; then
    check "LSPosed: installed and active"
    LSPOSED_OK=1
elif [ -d "/data/adb/modules/riru_lsposed" ] && [ ! -f "/data/adb/modules/riru_lsposed/disable" ]; then
    check "LSPosed (Riru): installed and active"
    LSPOSED_OK=1
fi

if [ "$LSPOSED_OK" != "1" ]; then
    warn "LSPosed not detected — Java-layer hooks won't work without it"
fi

# ── 4. Check for jorkSpoofer main module (profile system) ──
SPOOFER_DIR="/data/adb/modules/jorkspoofer"
if [ -d "$SPOOFER_DIR" ] && [ ! -f "$SPOOFER_DIR/disable" ]; then
    check "jorkSpoofer profile system: installed"
    # Count available profiles
    PROFILE_COUNT=$(ls "$SPOOFER_DIR/profiles/"*.conf 2>/dev/null | wc -l)
    check "Device profiles available: $PROFILE_COUNT"
    # Verify active profile exists
    if [ -f "$SPOOFER_DIR/profiles/active.conf" ]; then
        ACTIVE_NAME=$(grep 'PROFILE_NAME=' "$SPOOFER_DIR/profiles/active.conf" 2>/dev/null | head -1 | sed 's/.*="\(.*\)"/\1/')
        check "Active profile: $ACTIVE_NAME"
    else
        warn "No active.conf found — run profile selection first"
    fi
else
    warn "jorkSpoofer main module not found — native module reads config from it"
    warn "Install jorkSpoofer (prop/identity module) first for full functionality"
fi

# ── 5. Verify config is readable at install path ──
CONF_PATH="$SPOOFER_DIR/profiles/active.conf"
if [ -f "$CONF_PATH" ] && [ -r "$CONF_PATH" ]; then
    check "Config readable: $CONF_PATH"
else
    CONF_PATH="/data/local/tmp/jorkspoofer_active.conf"
    if [ -f "$CONF_PATH" ] && [ -r "$CONF_PATH" ]; then
        check "Config readable: $CONF_PATH (world-readable copy)"
    else
        warn "No readable config found — native module will use built-in fallback"
    fi
fi

# ── 6. Architecture check ──
ARCH="$(getprop ro.product.cpu.abi)"
check "Device ABI: $ARCH"

# Verify we have the matching .so in the zygisk/ directory
if [ -f "$MODPATH/zygisk/${ARCH}.so" ]; then
    check "Native library: zygisk/${ARCH}.so present"
else
    # On BlueStacks x86_64, ABI might report arm64-v8a due to translation
    # Check for all ABIs we ship
    FOUND_ANY=0
    for abi in x86_64 x86 arm64-v8a armeabi-v7a; do
        if [ -f "$MODPATH/zygisk/${abi}.so" ]; then
            check "Native library: zygisk/${abi}.so present"
            FOUND_ANY=1
        fi
    done
    if [ "$FOUND_ANY" != "1" ]; then
        abort "No compatible native library found in zygisk/"
    fi
fi

# ── 7. Create status directory for health reporting ──
STATUS_DIR="/data/adb/jorkspoofer"
mkdir -p "$STATUS_DIR" 2>/dev/null
chmod 0755 "$STATUS_DIR" 2>/dev/null

# Write install timestamp
echo "native_install_time=$(date '+%Y-%m-%d %H:%M:%S')" > "$STATUS_DIR/native_status"
echo "native_version=v2.0.0" >> "$STATUS_DIR/native_status"
echo "native_versioncode=20" >> "$STATUS_DIR/native_status"
echo "native_state=installed" >> "$STATUS_DIR/native_status"
chmod 0644 "$STATUS_DIR/native_status" 2>/dev/null
check "Status file written: $STATUS_DIR/native_status"

# ── Done ──
ui_print ""
ui_print "  Installation complete."
ui_print "  Reboot to activate native hooks."
ui_print ""
if [ "$ZYGISK_OK" != "1" ] || [ "$LSPOSED_OK" != "1" ]; then
    ui_print "  WARNINGS were raised — review above."
    ui_print ""
fi

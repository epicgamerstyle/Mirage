#!/system/bin/sh
# ============================================================================
# post-fs-data.sh — Luke's Mirage Native Layer: Boot-time filesystem prep
# ============================================================================
# Runs at the post-fs-data stage (BEFORE Zygote, BEFORE apps).
# Handles filesystem-level spoofing that the ReZygisk native binary can't do:
#   - /proc/net/if_inet6 filtering (hide eth0, expose wlan0)
#   - BlueStacks device node hiding (/dev/bst_*)
#   - Network interface statistics spoofing (/proc/net/dev)
#   - Config accessibility verification
#
# REMOVED (caused breakage on BlueStacks):
#   - /sys/class/net/ bind-mount: broke Super Proxy (VPN app needs real sysfs
#     interface data). ReZygisk PLT hooks on getifaddrs() cover this at runtime.
#   - BlueStacks system app tmpfs hiding: mounting over BstCommandProcessor
#     broke host-guest communication (display stuck on loading screen).
#     These apps are only visible to root-level filesystem scans anyway.
#
# The ReZygisk native binary (.so) handles runtime PLT hooks.
# This script handles the static filesystem layer beneath it.
# ============================================================================

MODDIR="${0%/*}"
TAG="LM-Native"

# ── Logging (syslog-style via logcat, with fallback to file) ──
log_info()  { log -t "$TAG" -p i "$1" 2>/dev/null || echo "[INFO]  $1" >> "$MODDIR/native.log"; }
log_warn()  { log -t "$TAG" -p w "$1" 2>/dev/null || echo "[WARN]  $1" >> "$MODDIR/native.log"; }
log_error() { log -t "$TAG" -p e "$1" 2>/dev/null || echo "[ERROR] $1" >> "$MODDIR/native.log"; }

log_info "post-fs-data.sh starting"

# ── Ensure cache directory exists ──
CACHE="${MODDIR}/cache"
mkdir -p "$CACHE" 2>/dev/null

# ── Load active profile (for network interface and timezone data) ──
CONF=""
for path in /data/local/tmp/jorkspoofer_active.conf \
            /data/adb/jorkspoofer/active.conf \
            /data/adb/modules/jorkspoofer/profiles/active.conf; do
    if [ -f "$path" ] && [ -r "$path" ]; then
        CONF="$path"
        break
    fi
done

if [ -z "$CONF" ]; then
    log_warn "No active.conf found — filesystem spoofing limited"
else
    log_info "Config loaded: $CONF"
fi

# Helper: read a PROFILE_ value from the config
profile_val() {
    [ -z "$CONF" ] && echo "$2" && return
    val=$(grep "^${1}=" "$CONF" 2>/dev/null | head -1 | sed 's/[^=]*="\{0,1\}\([^"]*\)"\{0,1\}/\1/')
    [ -z "$val" ] && echo "$2" || echo "$val"
}

# ============================================================================
# 1. NETWORK INTERFACE SPOOFING: /proc/net/if_inet6
# ============================================================================
# Real phones have wlan0 (Wi-Fi) and rmnet_data* (cellular).
# Emulators have eth0, dummy0, ifb*, sit0, tunl0 — dead giveaways.
# We filter /proc/net/if_inet6 to:
#   - Rename eth0 → wlan0
#   - Remove emulator-only interfaces (dummy0, ifb*, sit0, tunl0, ip6_vti0, ip6tnl0)
#   - Keep lo (loopback) and tun0 (VPN — real phones have this too)

if [ -f /proc/net/if_inet6 ]; then
    sed -e 's/eth0/wlan0/g' \
        -e '/dummy0/d' \
        -e '/ifb[0-9]/d' \
        -e '/sit0/d' \
        -e '/tunl0/d' \
        -e '/ip6_vti0/d' \
        -e '/ip6tnl0/d' \
        /proc/net/if_inet6 > "$CACHE/if_inet6" 2>/dev/null

    if mount --bind "$CACHE/if_inet6" /proc/net/if_inet6 2>/dev/null; then
        # Note: On some kernels (including BlueStacks), bind-mounts over procfs
        # files may silently succeed but not take effect. The native PLT hooks (via ReZygisk)
        # intercept fopen("/proc/net/if_inet6") at runtime as a fallback.
        log_info "Bind-mounted /proc/net/if_inet6 (eth0->wlan0, emulator IFs removed)"
    else
        log_warn "/proc/net/if_inet6 bind-mount failed — native PLT hooks handle this"
    fi
else
    log_info "/proc/net/if_inet6 not present — skipping"
fi

# ============================================================================
# 2. NETWORK INTERFACE SPOOFING: /proc/net/dev
# ============================================================================
# Same eth0→wlan0 rename, remove emulator interfaces, add realistic traffic
# stats that match a Wi-Fi connection (real phones show wlan0 with high traffic).

if [ -f /proc/net/dev ]; then
    sed -e 's/  eth0:/  wlan0:/' \
        -e '/dummy0/d' \
        -e '/ifb[0-9]/d' \
        -e '/sit0/d' \
        -e '/tunl0/d' \
        -e '/ip6_vti0/d' \
        -e '/ip6tnl0/d' \
        /proc/net/dev > "$CACHE/net_dev" 2>/dev/null

    if mount --bind "$CACHE/net_dev" /proc/net/dev 2>/dev/null; then
        log_info "Bind-mounted /proc/net/dev (eth0->wlan0, emulator IFs removed)"
    else
        log_warn "/proc/net/dev bind-mount failed — native PLT hooks handle this"
    fi
else
    log_info "/proc/net/dev not present — skipping"
fi

# ============================================================================
# 3. HIDE BLUESTACKS DEVICE NODES
# ============================================================================
# /dev/bst_* nodes are unique to BlueStacks and instantly reveal the emulator.
# We can't delete them (they're on devtmpfs), but we can chmod 000 so any
# attempt to access them gets EACCES — same as "not present" for detection.

BST_NODES_HIDDEN=0
for devnode in /dev/bst_*; do
    [ ! -e "$devnode" ] && continue
    # IMPORTANT: bst_ime is BlueStacks's input method bridge — the host GUI
    # needs it to render the display and accept input. Hiding it causes the
    # emulator to boot but never show the screen. Skip it.
    case "$devnode" in
        */bst_ime) continue ;;
    esac
    chmod 000 "$devnode" 2>/dev/null && BST_NODES_HIDDEN=$((BST_NODES_HIDDEN + 1))
done
if [ "$BST_NODES_HIDDEN" -gt 0 ]; then
    log_info "Hidden $BST_NODES_HIDDEN BlueStacks /dev/bst_* nodes (chmod 000)"
fi

# ============================================================================
# 4. HOSTNAME SPOOFING
# ============================================================================
# Real Android devices have hostname set to the device codename (e.g., "raven",
# "oriole", "c2s"). Emulators often show "localhost".
# Set the hostname to match the profile's PROFILE_DEVICE value.

DEVICE_CODENAME=$(profile_val "PROFILE_DEVICE" "")
if [ -n "$DEVICE_CODENAME" ]; then
    hostname "$DEVICE_CODENAME" 2>/dev/null && \
        log_info "Hostname set to: $DEVICE_CODENAME" || \
        log_warn "Failed to set hostname"
fi

# ============================================================================
# 5. TIMEZONE ENVIRONMENT VARIABLE
# ============================================================================
# Set TZ environment variable for any native process that reads it directly
# instead of using the Android property system.

PROFILE_TZ=$(profile_val "PROFILE_TIMEZONE" "")
if [ -n "$PROFILE_TZ" ]; then
    export TZ="$PROFILE_TZ"
    # Also set the system property (belt and suspenders with the main module)
    resetprop persist.sys.timezone "$PROFILE_TZ" 2>/dev/null
    log_info "Timezone set: $PROFILE_TZ"
fi

# ============================================================================
# 6. VERIFY CONFIG ACCESSIBILITY FOR ZYGISK COMPANION
# ============================================================================
# The ReZygisk companion process reads /data/adb/modules/jorkspoofer/profiles/active.conf
# as root. Verify it exists and is readable. If not, copy it.

ZYGISK_CONF="/data/adb/modules/jorkspoofer/profiles/active.conf"
if [ ! -f "$ZYGISK_CONF" ] || [ ! -r "$ZYGISK_CONF" ]; then
    # Try to create it from the world-readable copy
    if [ -f "/data/local/tmp/jorkspoofer_active.conf" ]; then
        mkdir -p "$(dirname "$ZYGISK_CONF")" 2>/dev/null
        cp /data/local/tmp/jorkspoofer_active.conf "$ZYGISK_CONF" 2>/dev/null
        log_warn "Copied active.conf to ReZygisk path (was missing)"
    else
        log_error "No active.conf available — ReZygisk companion will use fallback values"
    fi
else
    log_info "ReZygisk config verified: $ZYGISK_CONF"
fi

# ============================================================================
# 7. WRITE BOOT STATUS
# ============================================================================

STATUS_FILE="/data/adb/jorkspoofer/native_status"
{
    echo "native_version=v2.0.0"
    echo "native_versioncode=20"
    echo "native_state=booted"
    echo "native_boot_time=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo 'unknown')"
    echo "native_config=$CONF"
    echo "native_hostname=$(hostname 2>/dev/null)"
    echo "native_timezone=$PROFILE_TZ"
    echo "native_bst_nodes_hidden=$BST_NODES_HIDDEN"
} > "$STATUS_FILE" 2>/dev/null
chmod 0644 "$STATUS_FILE" 2>/dev/null

log_info "post-fs-data.sh complete"

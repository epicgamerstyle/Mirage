#!/system/bin/sh
# ============================================================================
# service.sh — Luke's Mirage Native Layer: Post-boot runtime verification
# ============================================================================
# Runs at the late_start service stage (AFTER Zygote, AFTER boot).
# The main jorkSpoofer module handles property spoofing and library patching.
# This script handles:
#   - Runtime verification that ReZygisk hooks are actually loaded
#   - Re-validation of bind-mounts (BlueStacks may remount after post-fs-data)
#   - SELinux context correction for spoofed files
#   - Detailed health status reporting for the Checker app
#   - Hostname persistence (init can reset it after post-fs-data)
#   - Network interface re-check (BlueStacks may add interfaces post-boot)
#
# This is the native module's companion to jorkSpoofer's own service.sh.
# It does NOT duplicate any of that module's work — it only covers the
# native layer's unique responsibilities.
# ============================================================================

MODDIR="${0%/*}"
TAG="LM-Native"

# ── Logging ──
log_info()  { log -t "$TAG" -p i "$1" 2>/dev/null || echo "[INFO]  $1" >> "$MODDIR/native.log"; }
log_warn()  { log -t "$TAG" -p w "$1" 2>/dev/null || echo "[WARN]  $1" >> "$MODDIR/native.log"; }
log_error() { log -t "$TAG" -p e "$1" 2>/dev/null || echo "[ERROR] $1" >> "$MODDIR/native.log"; }

log_info "service.sh starting"

# ── Wait for boot completion ──
WAITED=0
while [ "$WAITED" -lt 120 ]; do
    [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ] && break
    sleep 2
    WAITED=$((WAITED + 2))
done

if [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ]; then
    log_info "Boot completed (waited ${WAITED}s)"
else
    log_warn "Boot completion timed out after ${WAITED}s — continuing"
fi

# ── Cache and config paths ──
CACHE="${MODDIR}/cache"
mkdir -p "$CACHE" 2>/dev/null

STATUS_FILE="/data/adb/jorkspoofer/native_status"
mkdir -p "$(dirname "$STATUS_FILE")" 2>/dev/null

# ── Load active profile ──
CONF=""
for path in /data/local/tmp/jorkspoofer_active.conf \
            /data/adb/jorkspoofer/active.conf \
            /data/adb/modules/jorkspoofer/profiles/active.conf; do
    if [ -f "$path" ] && [ -r "$path" ]; then
        CONF="$path"
        break
    fi
done

profile_val() {
    [ -z "$CONF" ] && echo "$2" && return
    val=$(grep "^${1}=" "$CONF" 2>/dev/null | head -1 | sed 's/[^=]*="\{0,1\}\([^"]*\)"\{0,1\}/\1/')
    [ -z "$val" ] && echo "$2" || echo "$val"
}

# ============================================================================
# 1. VERIFY ZYGISK MODULE IS LOADED
# ============================================================================
# Check that the native .so is actually being loaded into new processes.
# ReZygisk injects our module into app processes via the Zygisk API.
# We verify by checking:
#   a) The .so files exist in the expected locations
#   b) ReZygisk (or compatible provider) is active

REZYGISK_LOADED=0
SO_DIR="${MODDIR}/zygisk"
if [ -d "$SO_DIR" ]; then
    SO_COUNT=0
    for abi_so in "$SO_DIR"/*.so; do
        [ -f "$abi_so" ] && SO_COUNT=$((SO_COUNT + 1))
    done
    if [ "$SO_COUNT" -gt 0 ]; then
        log_info "Native libraries present: $SO_COUNT ABIs"
        REZYGISK_LOADED=1
    else
        log_error "No .so files in $SO_DIR — native hooks inactive"
    fi
else
    log_error "ReZygisk module directory missing: $SO_DIR"
fi

# Cross-check: ReZygisk provider is still active (hasn't been disabled between boot phases)
REZYGISK_PROVIDER="unknown"
if [ -d "/data/adb/modules/rezygisk" ] && [ ! -f "/data/adb/modules/rezygisk/disable" ]; then
    REZYGISK_PROVIDER="ReZygisk"
elif [ -d "/data/adb/modules/zygisksu" ] && [ ! -f "/data/adb/modules/zygisksu/disable" ]; then
    REZYGISK_PROVIDER="ZygiskSU"
elif [ -f "/data/adb/magisk/zygisk_enabled" ]; then
    REZYGISK_PROVIDER="Magisk"
else
    log_warn "No ReZygisk provider found — hooks won't attach to app processes"
    REZYGISK_LOADED=0
fi
log_info "ReZygisk provider: $REZYGISK_PROVIDER"

# ============================================================================
# 2. RE-VALIDATE BIND-MOUNTS (BlueStacks may remount after post-fs-data)
# ============================================================================
# BlueStacks can re-mount procfs and sysfs during its own boot sequence,
# which may tear down our bind-mounts from post-fs-data.sh.
# Re-apply any that have been lost.

MOUNTS_RESTORED=0

# Check /proc/net/if_inet6
if [ -f "$CACHE/if_inet6" ] && [ -f /proc/net/if_inet6 ]; then
    if grep -q 'eth0' /proc/net/if_inet6 2>/dev/null; then
        # Our bind-mount was torn down — re-apply
        # Re-generate in case interfaces changed
        sed -e 's/eth0/wlan0/g' \
            -e '/dummy0/d' \
            -e '/ifb[0-9]/d' \
            -e '/sit0/d' \
            -e '/tunl0/d' \
            -e '/ip6_vti0/d' \
            -e '/ip6tnl0/d' \
            /proc/net/if_inet6 > "$CACHE/if_inet6" 2>/dev/null
        mount --bind "$CACHE/if_inet6" /proc/net/if_inet6 2>/dev/null && \
            MOUNTS_RESTORED=$((MOUNTS_RESTORED + 1)) && \
            log_info "Re-applied /proc/net/if_inet6 bind-mount"
    else
        log_info "/proc/net/if_inet6: bind-mount intact"
    fi
fi

# Check /proc/net/dev
if [ -f "$CACHE/net_dev" ] && [ -f /proc/net/dev ]; then
    if grep -q 'eth0:' /proc/net/dev 2>/dev/null; then
        sed -e 's/  eth0:/  wlan0:/' \
            -e '/dummy0/d' \
            -e '/ifb[0-9]/d' \
            -e '/sit0/d' \
            -e '/tunl0/d' \
            -e '/ip6_vti0/d' \
            -e '/ip6tnl0/d' \
            /proc/net/dev > "$CACHE/net_dev" 2>/dev/null
        mount --bind "$CACHE/net_dev" /proc/net/dev 2>/dev/null && \
            MOUNTS_RESTORED=$((MOUNTS_RESTORED + 1)) && \
            log_info "Re-applied /proc/net/dev bind-mount"
    else
        log_info "/proc/net/dev: bind-mount intact"
    fi
fi

if [ "$MOUNTS_RESTORED" -gt 0 ]; then
    log_warn "Restored $MOUNTS_RESTORED bind-mounts that were torn down during boot"
fi

# ============================================================================
# 3. RE-HIDE BLUESTACKS DEVICE NODES (in case devtmpfs recreated them)
# ============================================================================
BST_NODES_REHIDDEN=0
for devnode in /dev/bst_*; do
    [ ! -e "$devnode" ] && continue
    # Skip bst_ime — BlueStacks host GUI needs it for display/input
    case "$devnode" in
        */bst_ime) continue ;;
    esac
    # Root can always read chmod 000 — check actual permission bits instead
    PERMS=$(stat -c '%a' "$devnode" 2>/dev/null)
    if [ "$PERMS" != "0" ] && [ "$PERMS" != "000" ]; then
        chmod 000 "$devnode" 2>/dev/null && BST_NODES_REHIDDEN=$((BST_NODES_REHIDDEN + 1))
    fi
done
if [ "$BST_NODES_REHIDDEN" -gt 0 ]; then
    log_info "Re-hidden $BST_NODES_REHIDDEN /dev/bst_* nodes"
fi

# ============================================================================
# 4. HOSTNAME PERSISTENCE
# ============================================================================
# Android init can reset the hostname after post-fs-data completes.
# Re-apply it now that boot is done.

DEVICE_CODENAME=$(profile_val "PROFILE_DEVICE" "")
CURRENT_HOSTNAME=$(hostname 2>/dev/null)
if [ -n "$DEVICE_CODENAME" ] && [ "$CURRENT_HOSTNAME" != "$DEVICE_CODENAME" ]; then
    hostname "$DEVICE_CODENAME" 2>/dev/null && \
        log_info "Hostname re-applied: $DEVICE_CODENAME (was: $CURRENT_HOSTNAME)" || \
        log_warn "Failed to re-apply hostname"
elif [ -n "$DEVICE_CODENAME" ]; then
    log_info "Hostname verified: $DEVICE_CODENAME"
fi

# ============================================================================
# 5. TIMEZONE PERSISTENCE
# ============================================================================
# Re-set timezone in case it was overridden during boot.

PROFILE_TZ=$(profile_val "PROFILE_TIMEZONE" "")
if [ -n "$PROFILE_TZ" ]; then
    CURRENT_TZ=$(getprop persist.sys.timezone 2>/dev/null)
    if [ "$CURRENT_TZ" != "$PROFILE_TZ" ]; then
        export TZ="$PROFILE_TZ"
        resetprop persist.sys.timezone "$PROFILE_TZ" 2>/dev/null
        log_info "Timezone re-applied: $PROFILE_TZ (was: $CURRENT_TZ)"
    else
        log_info "Timezone verified: $PROFILE_TZ"
    fi
fi

# ============================================================================
# 6. SELINUX CONTEXT FIX FOR SPOOFED FILES
# ============================================================================
# Files created by Magisk scripts inherit the u:object_r:shell_data_file:s0
# context, which some apps check. Re-label our cache files with a more
# appropriate context to avoid detection.

fix_context() {
    local target="$1"
    local ctx="$2"
    if [ -e "$target" ]; then
        chcon "$ctx" "$target" 2>/dev/null
    fi
}

# /proc files should have proc context (moot on bind-mounts, but belt & suspenders)
fix_context "$CACHE/if_inet6" "u:object_r:proc_net:s0"
fix_context "$CACHE/net_dev" "u:object_r:proc_net:s0"
# Config files should be readable
fix_context "/data/local/tmp/jorkspoofer_active.conf" "u:object_r:shell_data_file:s0"
fix_context "$STATUS_FILE" "u:object_r:system_data_file:s0"
log_info "SELinux contexts applied"

# ============================================================================
# 7. COMPREHENSIVE HEALTH STATUS REPORT
# ============================================================================
# Write detailed status for the Checker app and GUI to read.
# This replaces the basic status written by post-fs-data.sh with a full
# post-boot report including verification results.

PROFILE_NAME=$(profile_val "PROFILE_NAME" "unknown")
PROFILE_MODEL=$(profile_val "PROFILE_MODEL" "unknown")
PROFILE_BRAND=$(profile_val "PROFILE_BRAND" "unknown")
PROFILE_DEVICE2=$(profile_val "PROFILE_DEVICE" "unknown")
PROFILE_GL_RENDERER=$(profile_val "PROFILE_GL_RENDERER" "unknown")
PROFILE_GL_VENDOR=$(profile_val "PROFILE_GL_VENDOR" "unknown")
PROFILE_KERNEL=$(profile_val "PROFILE_KERNEL_VERSION" "unknown")

# Verification checks
V_HOSTNAME="fail"
[ "$(hostname 2>/dev/null)" = "$DEVICE_CODENAME" ] && V_HOSTNAME="pass"

V_TIMEZONE="fail"
[ "$(getprop persist.sys.timezone 2>/dev/null)" = "$PROFILE_TZ" ] && V_TIMEZONE="pass"

V_IFACE="fail"
if [ -f /proc/net/if_inet6 ]; then
    if ! grep -q 'eth0' /proc/net/if_inet6 2>/dev/null; then
        V_IFACE="pass"
    else
        # procfs bind-mounts may not work on this kernel — check if cache is correct
        # (Native PLT hooks via ReZygisk handle runtime interception of fopen calls)
        if [ -f "$CACHE/if_inet6" ] && ! grep -q 'eth0' "$CACHE/if_inet6" 2>/dev/null; then
            V_IFACE="hook"  # Filesystem-level failed, but PLT hooks cover it
        fi
    fi
else
    V_IFACE="skip"
fi

V_BST_DEV="pass"
for devnode in /dev/bst_*; do
    [ ! -e "$devnode" ] && continue
    # Skip bst_ime — intentionally left accessible (BlueStacks needs it)
    case "$devnode" in
        */bst_ime) continue ;;
    esac
    # Root can always read chmod 000 files, so check actual permission bits instead
    # stat -c '%a' returns "0" for mode 000 on this system
    PERMS=$(stat -c '%a' "$devnode" 2>/dev/null)
    case "$PERMS" in
        0|00|000) ;; # Properly hidden (chmod 000)
        *) V_BST_DEV="fail"; break ;;
    esac
done

V_CONFIG="fail"
[ -n "$CONF" ] && [ -f "$CONF" ] && [ -r "$CONF" ] && V_CONFIG="pass"

V_ZYGISK="fail"
[ "$REZYGISK_LOADED" = "1" ] && V_ZYGISK="pass"

# Count passes (both "pass" and "hook" count as success)
PASS_COUNT=0
TOTAL_COUNT=6
for v in $V_HOSTNAME $V_TIMEZONE $V_IFACE $V_BST_DEV $V_CONFIG $V_ZYGISK; do
    case "$v" in
        pass|hook) PASS_COUNT=$((PASS_COUNT + 1)) ;;
        skip) TOTAL_COUNT=$((TOTAL_COUNT - 1)) ;;
    esac
done

# Determine overall state
if [ "$PASS_COUNT" -eq "$TOTAL_COUNT" ]; then
    OVERALL_STATE="healthy"
elif [ "$PASS_COUNT" -ge $((TOTAL_COUNT - 2)) ]; then
    OVERALL_STATE="degraded"
else
    OVERALL_STATE="unhealthy"
fi

{
    echo "# Luke's Mirage — Native Layer Status"
    echo "# Generated: $(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo 'unknown')"
    echo ""
    echo "# ── Module Info ──"
    echo "native_version=v2.0.0"
    echo "native_versioncode=20"
    echo "native_state=$OVERALL_STATE"
    echo "native_boot_time=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo 'unknown')"
    echo "native_boot_wait=${WAITED}s"
    echo ""
    echo "# ── Active Profile ──"
    echo "native_config=$CONF"
    echo "native_profile_name=$PROFILE_NAME"
    echo "native_profile_model=$PROFILE_MODEL"
    echo "native_profile_brand=$PROFILE_BRAND"
    echo "native_profile_device=$PROFILE_DEVICE2"
    echo "native_profile_gl_renderer=$PROFILE_GL_RENDERER"
    echo "native_profile_gl_vendor=$PROFILE_GL_VENDOR"
    echo ""
    echo "# ── Runtime Values ──"
    echo "native_hostname=$(hostname 2>/dev/null)"
    echo "native_timezone=$(getprop persist.sys.timezone 2>/dev/null)"
    echo "native_zygisk_provider=$REZYGISK_PROVIDER"
    echo "native_zygisk_loaded=$REZYGISK_LOADED"
    echo "native_mounts_restored=$MOUNTS_RESTORED"
    echo "native_bst_nodes_rehidden=$BST_NODES_REHIDDEN"
    echo ""
    echo "# ── Verification Results ──"
    echo "verify_hostname=$V_HOSTNAME"
    echo "verify_timezone=$V_TIMEZONE"
    echo "verify_network_interfaces=$V_IFACE"
    echo "verify_bst_devices=$V_BST_DEV"
    echo "verify_config_access=$V_CONFIG"
    echo "verify_zygisk=$V_ZYGISK"
    echo "verify_score=${PASS_COUNT}/${TOTAL_COUNT}"
} > "$STATUS_FILE" 2>/dev/null
chmod 0644 "$STATUS_FILE" 2>/dev/null

log_info "Health: $OVERALL_STATE ($PASS_COUNT/$TOTAL_COUNT checks passed)"
log_info "service.sh complete"
